package fr.univ_lyon1.info.m1.poneymon_v0;

import java.util.Random;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * 
 * Classe gerant un Poney
 *
 */
public class Poney 
{
	double x;       // position horizontale du poney
	double y; 	  // position verticale du poney
	double speed;   // vitesse du poney
	String poneyColor;

	Image poneyImage;	  
	GraphicsContext graphicsContext;

	/**
	 * Constructeur du Poney
	 * 
	 * @param gc ContextGraphic dans lequel on va afficher le poney
	 * @param color couleur du poney
	 * @param yInit position verticale
	 */
	Poney(GraphicsContext gc, String color, int yInit) 
	{
		// Tous les poneys commencent a gauche du canvas, 
		// on commence a -100 pour les faire apparaitre progressivement
		x = -100.0;               
		y = yInit;
		graphicsContext = gc;
		poneyColor=color;

		// On charge l'image  du Poney
		poneyImage = new Image("assets/pony-"+color+"-running.gif");

		// Tous les poneys ont une vitesse aleatoire entre 0.0 et 1.0
		Random randomGenerator = new Random();
		speed = randomGenerator.nextFloat();
	}

	/**
	 *  Affichage du poney
	 */
	void display() 
	{
		graphicsContext.drawImage(poneyImage, x, y);
	}

	/**
	 *  Deplacement du poney
	 */
	void move() 
	{
		x += speed;
		if (x > 520) 
		{
			x = -poneyImage.getWidth();
		}
	}

}
