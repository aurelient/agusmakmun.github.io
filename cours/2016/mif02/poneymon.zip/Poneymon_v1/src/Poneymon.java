import processing.core.PApplet;

public class Poneymon extends PApplet{

	  //	An array of stripes
	  Poney[] poneys = new Poney[3];
	  String[] colorMap = new String[] {"blue", "green", "orange", "purple", "yellow"};
	  
	  public static void main(String[] args){
	    PApplet.main("Poneymon");
	  }

	  
	  public void settings(){
	    size(600,400);
	  }


	  public void setup() {
	    // Initialize all "stripes"
	    for (int i = 0; i < poneys.length; i++) {
	    	poneys[i] = new Poney(this, colorMap[i], i*110);
	    }
	  }

	  public void draw() {
	    background(100);
	    // Move and display all "stripes"
	    for (int i = 0; i < poneys.length; i++) {
	    	poneys[i].move();
	    	poneys[i].display();
	    }
	  }
	  
}