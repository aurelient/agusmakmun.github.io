import processing.core.PApplet;
import gifAnimation.*;

public class Poney {

		  float x;      // horizontal of the poney
		  float y;		// vertical of the poney
		  float speed;   // speed of the poney
		  Gif illustration; 
		  PApplet parent; // The parent PApplet that we will render ourselves onto
		  
		  Poney(PApplet p, String color, int yInit) {
		    parent = p;
		    x = -20;              // All poneys start at 0
		    y = yInit;
		    illustration = new Gif(parent, "assets/pony-"+ color + "-running.gif");
		    illustration.play();
		    speed = parent.random(1);  // All poneys have a random positive speed
		  }

		  // Draw poney
		  void display() {
		    parent.image(illustration, x, y);
		    //parent.noStroke();
		  }

		  // Move poney
		  void move() {
		    x += speed;
		    if (x > parent.width) x = -20;
		  }

		  
}
